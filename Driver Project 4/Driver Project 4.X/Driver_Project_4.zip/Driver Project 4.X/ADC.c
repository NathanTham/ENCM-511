/*
 * File:   ADC.c
 * Author: Nathan
 *
 * Created on November 13, 2021, 4:58 PM
 */


#include "xc.h"

uint16_t ADC(void) 
{
    uint16_t ADCvalue;          //16 bit register used to hold ADC converted digital output ADC1BUF0
    
    //ADC Initialization 
    AD1CON1bits.ADON = 1;       //turn on ADC module
    AD1CON1bits.FORM = 00;      //set digital output as integer
    AD1CON1bits.SSRC = 111;     //internal counter ends sampling and starts conversion (auto-convert) )
    AD1CON1bits.ASAM = 0;       //sampling begins when user sets SAMP bit 
    
    AD1CON2bits.VCFG = 000;     //Use PIC supply voltage as reference voltage
    AD1CON2bits.CSCNA = 0;      //Only using one input
    AD1CON2bits.SMPI = 0001;    //Interrupts at the completion of conversion for each sample/convert sequence
    AD1CON2bits.BUFM = 0;       //Buffer configured as one 16-word buffer
    AD1CON2bits.ALTS = 0;       //Use MUX A input multiplexer settings
    
    AD1CON3bits.ADRC = 0;       //Clock derived from system clock 
    AD1CON3bits.SAMC = 00001;   //Auto-sample time bits     Slowest sampling time = 31*2/fclk   CHOOSE THIS VALUE
    AD1CON3bits.ADCS = 11111;   //A->D conversion clock select bits     CHOOSE THIS VALUE
    
    AD1CHSbits.CH0NA = 0;       //Set negative reference voltage as Vr-
    AD1CHSbits.CH0SA = 0101;    //Set positive analog input as AN5
    
    //ADC Sampling and Conversion 
    AD1CON1bits.SAMP = 1;        //Start sampling, conversion start automatically after (SSRC & SAMC settings)
    while(AD1CON1bits.DONE == 0)
    {
    }
    ADCvalue = ADC1BUF0;
    AD1CON1bits.SAMP = 0;       //Stop sampling
    AD1CON1bits.ADON = 0;       //Turn off ADC, ADC value stored in ADC1BUF0
    return(ADCvalue);
}

void __attribute__((interrupt, no_auto_psv)) __ADC1Interrupt(void)
{
    IFS0bits.AD1IF = 0;          //Clear ADC1 Interrupt Flag
}