#ifndef IOCHECK_H
#define	IOCHECK_H

void IOCheck();

#endif	/* IOCHECK_H*/