#ifndef TIMEDELAY_H
#define	TIMEDELAY_H

#include <xc.h> // include processor files - each processor file is guarded.  

void Delay_ms(uint16_t);

#endif	/* TIMEDELAY_H */

