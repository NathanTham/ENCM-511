#ifndef IOS_H
#define	IOS_H

#include <xc.h> // include processor files - each processor file is guarded.  

void IOinit(void);

#endif	/* IOS_H */

