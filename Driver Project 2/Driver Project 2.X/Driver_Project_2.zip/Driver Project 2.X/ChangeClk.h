#ifndef CHANGECLK_H
#define	CHANGECLK_H

#include <xc.h> // include processor files - each processor file is guarded.  

void ChangeClk(unsigned int);

#endif	/* CHANGECLK_H */

